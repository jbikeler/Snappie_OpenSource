# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "Snappie",
    "author" : "Ben Ikeler", 
    "description" : "",
    "blender" : (3, 0, 0),
    "version" : (2, 0, 0),
    "location" : "",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "3D View" 
}


import bpy
import bpy.utils.previews


addon_keymaps = {}
_icons = None


def find_user_keyconfig(key):
    km, kmi = addon_keymaps[key]
    for item in bpy.context.window_manager.keyconfigs.user.keymaps[km.name].keymap_items:
        found_item = False
        if kmi.idname == item.idname:
            found_item = True
            for name in dir(kmi.properties):
                if not name in ["bl_rna", "rna_type"] and not name[0] == "_":
                    if not kmi.properties[name] == item.properties[name]:
                        found_item = False
        if found_item:
            return item
    print(f"Couldn't find keymap item for {key}, using addon keymap instead. This won't be saved across sessions!")
    return kmi


def sna_update_sna_defaultsnapkey_3976E(self, context):
    sna_updated_prop = self.sna_defaultsnapkey

    def check_modifier_keys(kmi):
        kmi_modifiers = [kmi.map_type,kmi.type,kmi.value,kmi.repeat,kmi.any,kmi.shift_ui,kmi.ctrl_ui,kmi.alt_ui,kmi.oskey_ui,kmi.key_modifier]
        modifiers = ['KEYBOARD','S','PRESS',False,False,True,False,False,False,'NONE']
        #print(' Kmi List: ', kmi_modifiers)
        #print('Node List: ', modifiers)
        if kmi_modifiers == modifiers or (kmi.map_type == 'TIMER' and kmi.map_type == 'KEYBOARD') or (kmi.map_type == 'TEXTINPUT' and kmi.map_type == 'KEYBOARD'):
            return True
        else:
            return False
    kms = bpy.context.window_manager.keyconfigs.user.keymaps
    toggle = False
    km_name = '3d view'
    kmi_name = 'snap'
    kmi_idname = 'wm.call_menu_pie'
    kmi_props_name = 'VIEW3D_MT_snap_pie'
    kmi_active = sna_updated_prop
    kmi_use_kmi_properties_name = True
    break_loop = False
    for km in kms:
        for kmi in km.keymap_items:
            if kmi_use_kmi_properties_name:
                if km.name.lower() == km_name.lower() and kmi.name.lower() == kmi_name.lower() and kmi.idname.lower() == kmi_idname.lower() and check_modifier_keys(kmi) and kmi.properties.name.lower() == kmi_props_name.lower():
                    if toggle:
                        kmi.active = not kmi.active
                    else:
                        kmi.active = kmi_active
                    break_loop = True
                    break
            else:
                if km.name.lower() == km_name.lower() and kmi.name.lower() == kmi_name.lower() and kmi.idname.lower() == kmi_idname.lower() and check_modifier_keys(kmi):
                    if toggle:
                        kmi.active = not kmi.active
                    else:
                        kmi.active = kmi_active
                    break_loop = True
                    break
        if break_loop:
            break


class SNA_OT_Set_Object_Home_D7E37(bpy.types.Operator):
    bl_idname = "sna.set_object_home_d7e37"
    bl_label = "Set Object Home"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        sna_fnsethome_D2CB3()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Switch_Object_Position_A151E(bpy.types.Operator):
    bl_idname = "sna.switch_object_position_a151e"
    bl_label = "Switch Object Position"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        sna_fnswitch_5C672()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_Object_Target_E0Ed6(bpy.types.Operator):
    bl_idname = "sna.set_object_target_e0ed6"
    bl_label = "Set Object Target"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        sna_fnsettarget_9F441()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_fnsethome_D2CB3():
    if bpy.context.view_layer.objects.active.sna_homeisset:
        bpy.context.view_layer.objects.active.sna_homeisset = False
        bpy.context.view_layer.objects.active.sna_homeloc = (0.0, 0.0, 0.0)
        bpy.context.view_layer.objects.active.sna_homerot = (0.0, 0.0, 0.0)
    else:
        bpy.context.view_layer.objects.active.sna_homeisset = True
        bpy.context.view_layer.objects.active.sna_homeloc = bpy.context.view_layer.objects.active.location
        bpy.context.view_layer.objects.active.sna_homerot = bpy.context.view_layer.objects.active.rotation_euler


def sna_fnswitch_5C672():
    if bpy.context.view_layer.objects.active.sna_ishome:
        bpy.context.view_layer.objects.active.location = bpy.context.view_layer.objects.active.sna_targetloc
        bpy.context.view_layer.objects.active.rotation_euler = bpy.context.view_layer.objects.active.sna_targetrot
        bpy.context.view_layer.objects.active.sna_ishome = (not bpy.context.view_layer.objects.active.sna_ishome)
    else:
        bpy.context.view_layer.objects.active.location = bpy.context.view_layer.objects.active.sna_homeloc
        bpy.context.view_layer.objects.active.rotation_euler = bpy.context.view_layer.objects.active.sna_homerot
        bpy.context.view_layer.objects.active.sna_ishome = (not bpy.context.view_layer.objects.active.sna_ishome)


def sna_fnsettarget_9F441():
    if bpy.context.view_layer.objects.active.sna_targetisset:
        bpy.context.view_layer.objects.active.sna_targetisset = False
    else:
        bpy.context.view_layer.objects.active.sna_targetisset = True
        bpy.context.view_layer.objects.active.sna_targetloc = bpy.context.view_layer.objects.active.location
        bpy.context.view_layer.objects.active.sna_targetrot = bpy.context.view_layer.objects.active.rotation_euler


class SNA_OT_Align_Cursor_10176(bpy.types.Operator):
    bl_idname = "sna.align_cursor_10176"
    bl_label = "Align Cursor"
    bl_description = "Aligns 3D Cursor to the Active Object"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        sna_fnaligncursor_5DB0F()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Align_Object_Bda5B(bpy.types.Operator):
    bl_idname = "sna.align_object_bda5b"
    bl_label = "Align Object"
    bl_description = "Aligns Active Object to the 3D Cursor"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        sna_fnalignobject_EF8C8()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Reset_Cursor_Rotation_8Ff67(bpy.types.Operator):
    bl_idname = "sna.reset_cursor_rotation_8ff67"
    bl_label = "Reset Cursor Rotation"
    bl_description = "Zero 3D Cursor Rotation"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        sna_fnresetcursorrot_C24FF()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Reset_Cursor_Location_Cc2A9(bpy.types.Operator):
    bl_idname = "sna.reset_cursor_location_cc2a9"
    bl_label = "Reset Cursor Location"
    bl_description = "Zero 3D Cursor Location"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        sna_fnresetcursorloc_87D6F()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Reset_Object_Location_Cae08(bpy.types.Operator):
    bl_idname = "sna.reset_object_location_cae08"
    bl_label = "Reset Object Location"
    bl_description = "Zero Active Object's Location"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        sna_fnresetobjectloc_509D1()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Reset_Object_Rotation_Bbafc(bpy.types.Operator):
    bl_idname = "sna.reset_object_rotation_bbafc"
    bl_label = "Reset Object Rotation"
    bl_description = "Zero Active Object's Rotation"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        sna_fnresetobjectrot_054FE()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_fnaligncursor_5DB0F():
    bpy.context.scene.cursor.location = bpy.context.view_layer.objects.active.location
    bpy.context.scene.cursor.rotation_euler = bpy.context.view_layer.objects.active.rotation_euler


def sna_fnalignobject_EF8C8():
    bpy.context.view_layer.objects.active.location = bpy.context.scene.cursor.location
    bpy.context.view_layer.objects.active.rotation_euler = bpy.context.scene.cursor.rotation_euler


def sna_fnresetcursorloc_87D6F():
    bpy.context.scene.cursor.location = (0.0, 0.0, 0.0)


def sna_fnresetcursorrot_C24FF():
    if (bpy.context.scene.cursor.rotation_mode == 'QUATERNION'):
        bpy.context.scene.cursor.rotation_quaternion = (1.0, 0.0, 0.0, 0.0)
    else:
        if (bpy.context.scene.cursor.rotation_mode == 'AXIS_ANGLE'):
            bpy.context.scene.cursor.rotation_axis_angle = (0.0, 0.0, 1.0, 0.0)
        else:
            bpy.context.scene.cursor.rotation_euler = (0.0, 0.0, 0.0)


def sna_fnzeroobjectrot_57A9B(Object):
    if (Object.rotation_mode == 'QUATERNION'):
        Object.rotation_quaternion = (1.0, 0.0, 0.0, 0.0)
    else:
        if (Object.rotation_mode == 'AXIS_ANGLE'):
            Object.rotation_axis_angle = (0.0, 0.0, 1.0, 0.0)
        else:
            Object.rotation_euler = (0.0, 0.0, 0.0)


def sna_fnresetobjectloc_509D1():
    bpy.context.view_layer.objects.active.location = (0.0, 0.0, 0.0)


def sna_fnresetobjectrot_054FE():
    sna_fnzeroobjectrot_57A9B(bpy.context.view_layer.objects.active)


class SNA_MT_61036(bpy.types.Menu):
    bl_idname = "SNA_MT_61036"
    bl_label = "Snappie"

    @classmethod
    def poll(cls, context):
        return not ((not (('EDIT_MESH'==bpy.context.mode or 'OBJECT'==bpy.context.mode) and bpy.context.view_layer.objects.active)))

    def draw(self, context):
        layout = self.layout.menu_pie()
        layout.separator(factor=1.0)
        layout.separator(factor=1.0)
        layout.separator(factor=1.0)
        if 'OBJECT'==bpy.context.mode:
            box_80D8B = layout.box()
            box_80D8B.alert = False
            box_80D8B.enabled = True
            box_80D8B.active = True
            box_80D8B.use_property_split = False
            box_80D8B.use_property_decorate = False
            box_80D8B.alignment = 'Expand'.upper()
            box_80D8B.scale_x = 1.0
            box_80D8B.scale_y = 1.0
            box_80D8B.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            col_F9A61 = box_80D8B.column(heading='', align=False)
            col_F9A61.alert = False
            col_F9A61.enabled = True
            col_F9A61.active = True
            col_F9A61.use_property_split = False
            col_F9A61.use_property_decorate = False
            col_F9A61.scale_x = 1.0
            col_F9A61.scale_y = 1.0
            col_F9A61.alignment = 'Expand'.upper()
            col_F9A61.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            split_8A2C8 = col_F9A61.split(factor=0.5, align=True)
            split_8A2C8.alert = False
            split_8A2C8.enabled = True
            split_8A2C8.active = True
            split_8A2C8.use_property_split = False
            split_8A2C8.use_property_decorate = False
            split_8A2C8.scale_x = 1.100000023841858
            split_8A2C8.scale_y = 1.2000000476837158
            split_8A2C8.alignment = 'Expand'.upper()
            split_8A2C8.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            op = split_8A2C8.operator('sna.set_object_home_d7e37', text='', icon_value=673, emboss=True, depress=bpy.context.view_layer.objects.active.sna_homeisset)
            op = split_8A2C8.operator('sna.set_object_target_e0ed6', text='', icon_value=566, emboss=True, depress=bpy.context.view_layer.objects.active.sna_targetisset)
            split_12DDF = col_F9A61.split(factor=1.0, align=False)
            split_12DDF.alert = False
            split_12DDF.enabled = True
            split_12DDF.active = True
            split_12DDF.use_property_split = False
            split_12DDF.use_property_decorate = False
            split_12DDF.scale_x = 1.100000023841858
            split_12DDF.scale_y = 1.2999999523162842
            split_12DDF.alignment = 'Expand'.upper()
            split_12DDF.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            op = split_12DDF.operator('sna.switch_object_position_a151e', text='', icon_value=8, emboss=True, depress=False)
        else:
            layout.separator(factor=1.0)
        box_EADF6 = layout.box()
        box_EADF6.alert = False
        box_EADF6.enabled = True
        box_EADF6.active = True
        box_EADF6.use_property_split = False
        box_EADF6.use_property_decorate = False
        box_EADF6.alignment = 'Expand'.upper()
        box_EADF6.scale_x = 1.0
        box_EADF6.scale_y = 1.100000023841858
        box_EADF6.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        split_FCB8F = box_EADF6.split(factor=0.5, align=False)
        split_FCB8F.alert = False
        split_FCB8F.enabled = True
        split_FCB8F.active = True
        split_FCB8F.use_property_split = False
        split_FCB8F.use_property_decorate = False
        split_FCB8F.scale_x = 1.0
        split_FCB8F.scale_y = 1.0
        split_FCB8F.alignment = 'Expand'.upper()
        split_FCB8F.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        split_FCB8F.label(text='Cursor To', icon_value=0)
        split_8B5C5 = split_FCB8F.split(factor=0.5, align=True)
        split_8B5C5.alert = False
        split_8B5C5.enabled = True
        split_8B5C5.active = True
        split_8B5C5.use_property_split = False
        split_8B5C5.use_property_decorate = False
        split_8B5C5.scale_x = 1.0
        split_8B5C5.scale_y = 1.0
        split_8B5C5.alignment = 'Expand'.upper()
        split_8B5C5.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = split_8B5C5.operator('sna.reset_cursor_location_cc2a9', text='', icon_value=595, emboss=True, depress=False)
        op = split_8B5C5.operator('sna.reset_cursor_rotation_8ff67', text='', icon_value=425, emboss=True, depress=False)
        col_C4D3A = box_EADF6.column(heading='', align=False)
        col_C4D3A.alert = False
        col_C4D3A.enabled = True
        col_C4D3A.active = True
        col_C4D3A.use_property_split = False
        col_C4D3A.use_property_decorate = False
        col_C4D3A.scale_x = 1.0
        col_C4D3A.scale_y = 1.0
        col_C4D3A.alignment = 'Expand'.upper()
        col_C4D3A.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_C4D3A.operator('view3d.snap_cursor_to_active', text='Active', icon_value=0, emboss=True, depress=False)
        op = col_C4D3A.operator('view3d.snap_cursor_to_selected', text='Selected', icon_value=0, emboss=True, depress=False)
        op = col_C4D3A.operator('view3d.snap_cursor_to_center', text='World Origin', icon_value=0, emboss=True, depress=False)
        if bpy.context.scene.sna_showgrid:
            op = col_C4D3A.operator('view3d.snap_cursor_to_grid', text='Grid', icon_value=0, emboss=True, depress=False)
        box_490BB = layout.box()
        box_490BB.alert = False
        box_490BB.enabled = True
        box_490BB.active = True
        box_490BB.use_property_split = False
        box_490BB.use_property_decorate = False
        box_490BB.alignment = 'Expand'.upper()
        box_490BB.scale_x = 1.0
        box_490BB.scale_y = 1.100000023841858
        box_490BB.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        split_EF29C = box_490BB.split(factor=0.550000011920929, align=False)
        split_EF29C.alert = False
        split_EF29C.enabled = True
        split_EF29C.active = True
        split_EF29C.use_property_split = False
        split_EF29C.use_property_decorate = False
        split_EF29C.scale_x = 1.100000023841858
        split_EF29C.scale_y = 1.0
        split_EF29C.alignment = 'Expand'.upper()
        split_EF29C.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        split_EF29C.label(text='Selection To', icon_value=0)
        if 'OBJECT'==bpy.context.mode:
            split_371B0 = split_EF29C.split(factor=0.5, align=True)
            split_371B0.alert = False
            split_371B0.enabled = True
            split_371B0.active = True
            split_371B0.use_property_split = False
            split_371B0.use_property_decorate = False
            split_371B0.scale_x = 1.0
            split_371B0.scale_y = 1.0
            split_371B0.alignment = 'Expand'.upper()
            split_371B0.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            op = split_371B0.operator('sna.reset_object_location_cae08', text='', icon_value=595, emboss=True, depress=False)
            op = split_371B0.operator('sna.reset_object_rotation_bbafc', text='', icon_value=425, emboss=True, depress=False)
        col_7002F = box_490BB.column(heading='', align=False)
        col_7002F.alert = False
        col_7002F.enabled = True
        col_7002F.active = True
        col_7002F.use_property_split = False
        col_7002F.use_property_decorate = False
        col_7002F.scale_x = 1.0
        col_7002F.scale_y = 1.0
        col_7002F.alignment = 'Expand'.upper()
        col_7002F.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_7002F.operator('view3d.snap_selected_to_cursor', text='Cursor', icon_value=0, emboss=True, depress=False)
        op = col_7002F.operator('view3d.snap_selected_to_cursor', text='Cursor(Keep Offset)', icon_value=0, emboss=True, depress=False)
        op.use_offset = True
        op = col_7002F.operator('view3d.snap_selected_to_active', text='Active', icon_value=0, emboss=True, depress=False)
        if bpy.context.scene.sna_showgrid:
            op = col_7002F.operator('view3d.snap_selected_to_grid', text='Grid', icon_value=0, emboss=True, depress=False)
        if 'OBJECT'==bpy.context.mode:
            op = layout.operator('sna.align_cursor_10176', text='Align Cursor', icon_value=0, emboss=True, depress=False)
        if 'OBJECT'==bpy.context.mode:
            op = layout.operator('sna.align_object_bda5b', text='Align Object', icon_value=0, emboss=True, depress=False)


class SNA_AddonPreferences_4796E(bpy.types.AddonPreferences):
    bl_idname = 'snappie'

    def draw(self, context):
        if not (False):
            layout = self.layout 
            split_5B18A = layout.split(factor=0.5, align=True)
            split_5B18A.alert = False
            split_5B18A.enabled = True
            split_5B18A.active = True
            split_5B18A.use_property_split = False
            split_5B18A.use_property_decorate = False
            split_5B18A.scale_x = 1.0
            split_5B18A.scale_y = 1.2999999523162842
            split_5B18A.alignment = 'Expand'.upper()
            split_5B18A.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            op = split_5B18A.operator('sna.set_general_tab_5dbe0', text='GENERAL', icon_value=0, emboss=True, depress=(bpy.context.scene.sna_preftabs == 'General'))
            op = split_5B18A.operator('sna.set_about_tab_ebc67', text='ABOUT', icon_value=0, emboss=True, depress=(bpy.context.scene.sna_preftabs == 'About'))
            if (bpy.context.scene.sna_preftabs == 'General'):
                col_57736 = layout.column(heading='', align=False)
                col_57736.alert = False
                col_57736.enabled = True
                col_57736.active = True
                col_57736.use_property_split = False
                col_57736.use_property_decorate = False
                col_57736.scale_x = 1.0
                col_57736.scale_y = 1.0
                col_57736.alignment = 'Expand'.upper()
                col_57736.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                col_57736.prop(find_user_keyconfig('D007D'), 'type', text='', full_event=True)
                col_57736.prop(bpy.context.scene, 'sna_showgrid', text='Display "Snap to Grid" options', icon_value=0, emboss=True)
                col_57736.prop(bpy.context.window_manager, 'sna_defaultsnapkey', text='Default "Snap" pie menu active?', icon_value=0, emboss=True)
            else:
                col_D80FD = layout.column(heading='', align=True)
                col_D80FD.alert = False
                col_D80FD.enabled = True
                col_D80FD.active = True
                col_D80FD.use_property_split = False
                col_D80FD.use_property_decorate = False
                col_D80FD.scale_x = 1.0
                col_D80FD.scale_y = 1.0
                col_D80FD.alignment = 'Expand'.upper()
                col_D80FD.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                col_D0834 = col_D80FD.column(heading='', align=True)
                col_D0834.alert = False
                col_D0834.enabled = True
                col_D0834.active = True
                col_D0834.use_property_split = False
                col_D0834.use_property_decorate = False
                col_D0834.scale_x = 1.0
                col_D0834.scale_y = 1.0
                col_D0834.alignment = 'Expand'.upper()
                col_D0834.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                col_D0834.label(text='What this addon is for?', icon_value=0)
                col_DEEF6 = col_D0834.column(heading='', align=True)
                col_DEEF6.alert = False
                col_DEEF6.enabled = True
                col_DEEF6.active = True
                col_DEEF6.use_property_split = False
                col_DEEF6.use_property_decorate = False
                col_DEEF6.scale_x = 1.0
                col_DEEF6.scale_y = 0.8500000238418579
                col_DEEF6.alignment = 'Expand'.upper()
                col_DEEF6.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                col_DEEF6.label(text='Organize default Snapping Pie Menu in Blender', icon_value=17)
                col_DEEF6.label(text='Block out projects', icon_value=17)
                col_DEEF6.label(text='A helpful Object Mode workflow', icon_value=17)
                col_D0834.label(text='What this addon is NOT for?', icon_value=0)
                split_94CF8 = col_D0834.split(factor=0.5, align=False)
                split_94CF8.alert = False
                split_94CF8.enabled = True
                split_94CF8.active = True
                split_94CF8.use_property_split = False
                split_94CF8.use_property_decorate = False
                split_94CF8.scale_x = 1.0
                split_94CF8.scale_y = 1.0
                split_94CF8.alignment = 'Expand'.upper()
                split_94CF8.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                split_94CF8.label(text='Snapping faces, edges or verts to one another. For that I would try MACHIN3tools(free).', icon_value=17)
                op = split_94CF8.operator('sna.mtools_link_6c131', text='MACHIN3tools Link', icon_value=0, emboss=True, depress=False)
                col_D0834.separator(factor=1.4199999570846558)
                col_5CC63 = col_D0834.column(heading='', align=True)
                col_5CC63.alert = False
                col_5CC63.enabled = True
                col_5CC63.active = True
                col_5CC63.use_property_split = False
                col_5CC63.use_property_decorate = False
                col_5CC63.scale_x = 1.0
                col_5CC63.scale_y = 0.800000011920929
                col_5CC63.alignment = 'Expand'.upper()
                col_5CC63.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                col_5CC63.label(text='Thanks for trying out Snappie. This is a simple project I use in my workflow all the time.', icon_value=0)
                col_5CC63.label(text='If there are any bugs feel free to let me know at the email linked to the marketplace ', icon_value=0)
                col_5CC63.label(text="you downloaded the addon from. I'm not the most experience dev, but I'll do my best to fix it:)", icon_value=0)


class SNA_OT_Set_General_Tab_5Dbe0(bpy.types.Operator):
    bl_idname = "sna.set_general_tab_5dbe0"
    bl_label = "Set General Tab"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        bpy.context.scene.sna_preftabs = 'General'
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_About_Tab_Ebc67(bpy.types.Operator):
    bl_idname = "sna.set_about_tab_ebc67"
    bl_label = "Set About Tab"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        bpy.context.scene.sna_preftabs = 'About'
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Mtools_Link_6C131(bpy.types.Operator):
    bl_idname = "sna.mtools_link_6c131"
    bl_label = "MTools Link"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        exec('bpy.ops.wm.url_open(url="https://machin3.gumroad.com/l/MACHIN3tools")')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.types.Scene.sna_showgrid = bpy.props.BoolProperty(name='ShowGrid', description='', default=False)
    bpy.types.Object.sna_homeloc = bpy.props.FloatVectorProperty(name='HomeLoc', description='', size=3, default=(0.0, 0.0, 0.0), subtype='NONE', unit='NONE', step=3, precision=6)
    bpy.types.Object.sna_homerot = bpy.props.FloatVectorProperty(name='HomeRot', description='', size=3, default=(0.0, 0.0, 0.0), subtype='NONE', unit='NONE', step=3, precision=6)
    bpy.types.Object.sna_targetloc = bpy.props.FloatVectorProperty(name='TargetLoc', description='', size=3, default=(0.0, 0.0, 0.0), subtype='NONE', unit='NONE', step=3, precision=6)
    bpy.types.Object.sna_targetrot = bpy.props.FloatVectorProperty(name='TargetRot', description='', size=3, default=(0.0, 0.0, 0.0), subtype='NONE', unit='NONE', step=3, precision=6)
    bpy.types.Object.sna_ishome = bpy.props.BoolProperty(name='IsHome', description='', default=False)
    bpy.types.Object.sna_homeisset = bpy.props.BoolProperty(name='HomeIsSet', description='', default=False)
    bpy.types.Object.sna_targetisset = bpy.props.BoolProperty(name='TargetIsSet', description='', default=False)
    bpy.types.Scene.sna_preftabs = bpy.props.StringProperty(name='PrefTabs', description='', default='General', subtype='NONE', maxlen=0)
    bpy.types.WindowManager.sna_defaultsnapkey = bpy.props.BoolProperty(name='DefaultSnapKey', description='', default=False, update=sna_update_sna_defaultsnapkey_3976E)
    bpy.utils.register_class(SNA_OT_Set_Object_Home_D7E37)
    bpy.utils.register_class(SNA_OT_Switch_Object_Position_A151E)
    bpy.utils.register_class(SNA_OT_Set_Object_Target_E0Ed6)
    bpy.utils.register_class(SNA_OT_Align_Cursor_10176)
    bpy.utils.register_class(SNA_OT_Align_Object_Bda5B)
    bpy.utils.register_class(SNA_OT_Reset_Cursor_Rotation_8Ff67)
    bpy.utils.register_class(SNA_OT_Reset_Cursor_Location_Cc2A9)
    bpy.utils.register_class(SNA_OT_Reset_Object_Location_Cae08)
    bpy.utils.register_class(SNA_OT_Reset_Object_Rotation_Bbafc)
    bpy.utils.register_class(SNA_MT_61036)
    bpy.utils.register_class(SNA_AddonPreferences_4796E)
    bpy.utils.register_class(SNA_OT_Set_General_Tab_5Dbe0)
    bpy.utils.register_class(SNA_OT_Set_About_Tab_Ebc67)
    bpy.utils.register_class(SNA_OT_Mtools_Link_6C131)
    kc = bpy.context.window_manager.keyconfigs.addon
    km = kc.keymaps.new(name='3D View', space_type='VIEW_3D')
    kmi = km.keymap_items.new('wm.call_menu_pie', 'S', 'PRESS',
        ctrl=False, alt=False, shift=True, repeat=False)
    kmi.properties.name = 'SNA_MT_61036'
    addon_keymaps['D007D'] = (km, kmi)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.WindowManager.sna_defaultsnapkey
    del bpy.types.Scene.sna_preftabs
    del bpy.types.Object.sna_targetisset
    del bpy.types.Object.sna_homeisset
    del bpy.types.Object.sna_ishome
    del bpy.types.Object.sna_targetrot
    del bpy.types.Object.sna_targetloc
    del bpy.types.Object.sna_homerot
    del bpy.types.Object.sna_homeloc
    del bpy.types.Scene.sna_showgrid
    bpy.utils.unregister_class(SNA_OT_Set_Object_Home_D7E37)
    bpy.utils.unregister_class(SNA_OT_Switch_Object_Position_A151E)
    bpy.utils.unregister_class(SNA_OT_Set_Object_Target_E0Ed6)
    bpy.utils.unregister_class(SNA_OT_Align_Cursor_10176)
    bpy.utils.unregister_class(SNA_OT_Align_Object_Bda5B)
    bpy.utils.unregister_class(SNA_OT_Reset_Cursor_Rotation_8Ff67)
    bpy.utils.unregister_class(SNA_OT_Reset_Cursor_Location_Cc2A9)
    bpy.utils.unregister_class(SNA_OT_Reset_Object_Location_Cae08)
    bpy.utils.unregister_class(SNA_OT_Reset_Object_Rotation_Bbafc)
    bpy.utils.unregister_class(SNA_MT_61036)
    bpy.utils.unregister_class(SNA_AddonPreferences_4796E)
    bpy.utils.unregister_class(SNA_OT_Set_General_Tab_5Dbe0)
    bpy.utils.unregister_class(SNA_OT_Set_About_Tab_Ebc67)
    bpy.utils.unregister_class(SNA_OT_Mtools_Link_6C131)
