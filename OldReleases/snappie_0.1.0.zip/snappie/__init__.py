# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#
# This addon was created with the Serpens - Visual Scripting Addon.
# This code is generated from nodes and is not intended for manual editing.
# You can find out more about Serpens at <https://blendermarket.com/products/serpens>.


bl_info = {
    "name": "Snappie",
    "description": "Cleaner version of the Snap Pie Menu (with some other goodies thrown in).",
    "author": "Ben Ikeler",
    "version": (0, 1, 0),
    "blender": (2, 92, 0),
    "location": "",
    "warning": "",
    "wiki_url": "",
    "tracker_url": "",
    "category": "3D View"
}


###############   IMPORTS
import bpy
from bpy.utils import previews
import os
import math


###############   INITALIZE VARIABLES
fnquickscripts = {
    "savedloc": [], 
    }
fnmovecursorlocal = {
    "moveammount": 0.0, 
    }


###############   SERPENS FUNCTIONS
def exec_line(line):
    exec(line)

def sn_print(tree_name, *args):
    if tree_name in bpy.data.node_groups:
        item = bpy.data.node_groups[tree_name].sn_graphs[0].prints.add()
        for arg in args:
            item.value += str(arg) + ";;;"
        if bpy.context and bpy.context.screen:
            for area in bpy.context.screen.areas:
                area.tag_redraw()
    print(*args)

def sn_cast_string(value):
    return str(value)

def sn_cast_boolean(value):
    if type(value) == tuple:
        for data in value:
            if bool(data):
                return True
        return False
    return bool(value)

def sn_cast_float(value):
    if type(value) == str:
        try:
            value = float(value)
            return value
        except:
            return float(bool(value))
    elif type(value) == tuple:
        return float(value[0])
    elif type(value) == list:
        return float(len(value))
    elif not type(value) in [float, int, bool]:
        try:
            value = len(value)
            return float(value)
        except:
            return float(bool(value))
    return float(value)

def sn_cast_int(value):
    return int(sn_cast_float(value))

def sn_cast_boolean_vector(value, size):
    if type(value) in [str, bool, int, float]:
        return_value = []
        for i in range(size):
            return_value.append(bool(value))
        return tuple(return_value)
    elif type(value) == tuple:
        return_value = []
        for i in range(size):
            return_value.append(bool(value[i]) if len(value) > i else bool(value[0]))
        return tuple(return_value)
    elif type(value) == list:
        return sn_cast_boolean_vector(tuple(value), size)
    else:
        try:
            value = tuple(value)
            return sn_cast_boolean_vector(value, size)
        except:
            return sn_cast_boolean_vector(bool(value), size)

def sn_cast_float_vector(value, size):
    if type(value) in [str, bool, int, float]:
        return_value = []
        for i in range(size):
            return_value.append(sn_cast_float(value))
        return tuple(return_value)
    elif type(value) == tuple:
        return_value = []
        for i in range(size):
            return_value.append(sn_cast_float(value[i]) if len(value) > i else sn_cast_float(value[0]))
        return tuple(return_value)
    elif type(value) == list:
        return sn_cast_float_vector(tuple(value), size)
    else:
        try:
            value = tuple(value)
            return sn_cast_float_vector(value, size)
        except:
            return sn_cast_float_vector(sn_cast_float(value), size)

def sn_cast_int_vector(value, size):
    return tuple(map(int, sn_cast_float_vector(value, size)))

def sn_cast_color(value, use_alpha):
    length = 4 if use_alpha else 3
    value = sn_cast_float_vector(value, length)
    tuple_list = []
    for data in range(length):
        data = value[data] if len(value) > data else value[0]
        tuple_list.append(sn_cast_float(min(1, max(0, data))))
    return tuple(tuple_list)

def sn_cast_list(value):
    if type(value) in [str, tuple, list]:
        return list(value)
    elif type(value) in [int, float, bool]:
        return [value]
    else:
        try:
            value = list(value)
            return value
        except:
            return [value]

def sn_cast_blend_data(value):
    if hasattr(value, "bl_rna"):
        return value
    elif type(value) in [tuple, bool, int, float, list]:
        return None
    elif type(value) == str:
        try:
            value = eval(value)
            return value
        except:
            return None
    else:
        return None

def sn_cast_enum(string, enum_values):
    for item in enum_values:
        if item[1] == string:
            return item[0]
        elif item[0] == string.upper():
            return item[0]
    return string


###############   IMPERATIVE CODE
#######   Snappie
addon_keymaps = []


#######   FN-QuickScripts
def fnalignobjecttocursor():
    try:
        bpy.context.active_object.location = bpy.context.scene.cursor.location
        bpy.context.active_object.rotation_euler = bpy.context.scene.cursor.rotation_euler
    except Exception as exc:
        print(str(exc) + " | Error in function fnAlignObjectToCursor")

def fnresetcursor():
    try:
        bpy.context.scene.cursor.rotation_euler = (0.0, 0.0, 0.0)
    except Exception as exc:
        print(str(exc) + " | Error in function fnResetCursor")

def fnaligncursortoactive():
    try:
        bpy.context.scene.cursor.location = bpy.context.active_object.location
        bpy.context.scene.cursor.rotation_euler = bpy.context.active_object.rotation_euler
    except Exception as exc:
        print(str(exc) + " | Error in function fnAlignCursorToActive")


#######   FN-MoveCursorLocal
def update_cursorzaxis(self, context):
    pass


#######   FN-Isolate
def update_targettoggle(self, context):
    if self.targettoggle:
        sn_cast_blend_data(self).targetloc = sn_cast_blend_data(self).location
        sn_cast_blend_data(self).targetrot = sn_cast_blend_data(self).rotation_euler
    else:
        sn_cast_blend_data(self).targetloc = (0.0, 0.0, 0.0)
        sn_cast_blend_data(self).targetrot = (0.0, 0.0, 0.0)

def fnswitchisolationmode():
    try:
        if bpy.context.active_object.switchtoggle:
            sn_cast_blend_data(bpy.context.active_object).location = sn_cast_blend_data(bpy.context.active_object).targetloc
            sn_cast_blend_data(bpy.context.active_object).rotation_euler = sn_cast_blend_data(bpy.context.active_object).targetrot
            sn_cast_blend_data(bpy.context.active_object).switchtoggle = False
        else:
            sn_cast_blend_data(bpy.context.active_object).location = sn_cast_blend_data(bpy.context.active_object).homeloc
            sn_cast_blend_data(bpy.context.active_object).rotation_euler = sn_cast_blend_data(bpy.context.active_object).homerot
            sn_cast_blend_data(bpy.context.active_object).switchtoggle = True
    except Exception as exc:
        print(str(exc) + " | Error in function fnSwitchIsolationMode")

def update_hometoggle(self, context):
    if self.hometoggle:
        sn_cast_blend_data(self).homeloc = sn_cast_blend_data(self).location
        sn_cast_blend_data(self).homerot = sn_cast_blend_data(self).rotation_euler
    else:
        pass


#######   SnappiePrefsGraph
def changelog_interface_snippet_F857E(layout, changes_list, icon, ):
    try:


        layout.label(text=(r"Changelog for Version " + sn_cast_string(bl_info["version"]).replace(r"(", r"").replace(r")", r"").replace(r",", r".") + r" :"),icon_value=0)
        if sn_cast_boolean(changes_list):
            for_node_F9F28 = 0
            for_node_index_F9F28 = 0
            for for_node_index_F9F28, for_node_F9F28 in enumerate(sn_cast_list(changes_list)):
                layout.label(text=sn_cast_string(for_node_F9F28),icon_value=icon)
        else:
            pass
    except Exception as exc:
        print(str(exc) + " | Error in function Changelog Interface")


###############   EVALUATED CODE
#######   Snappie
class SNA_MT_Snappie_4FE70(bpy.types.Menu):
    bl_idname = "SNA_MT_Snappie_4FE70"
    bl_label = "Snappie"


    @classmethod
    def poll(cls, context):
        return ("EDIT_MESH"==bpy.context.mode or "OBJECT"==bpy.context.mode)

    def draw(self, context):
        try:
            layout = self.layout
            layout = layout.menu_pie()
            layout.separator(factor=1.0)
            layout.separator(factor=1.0)
            layout.separator(factor=1.0)
            box = layout.box()
            box.enabled = True
            box.alert = False
            box.scale_x = 1.0
            box.scale_y = 1.0
            split = box.split(align=True,factor=0.5)
            split.enabled = True
            split.alert = False
            split.scale_x = 1.0
            split.scale_y = 1.0
            split.prop(bpy.context.active_object,'hometoggle',icon_value=673,text=r"",emboss=True,toggle=False,invert_checkbox=False,)
            split.prop(bpy.context.active_object,'targettoggle',icon_value=566,text=r"",emboss=True,toggle=False,invert_checkbox=False,)
            split = box.split(align=True,factor=1.0)
            split.enabled = True
            split.alert = False
            split.scale_x = 1.0
            split.scale_y = 1.5
            op = split.operator("sna.switchposition",text=r"",emboss=True,depress=False,icon_value=8)
            box = layout.box()
            box.enabled = True
            box.alert = False
            box.scale_x = 1.0
            box.scale_y = 1.0
            split = box.split(align=False,factor=0.7016128897666931)
            split.enabled = True
            split.alert = False
            split.scale_x = 1.0
            split.scale_y = 1.0
            split.label(text=r"Cursor To",icon_value=0)
            op = split.operator("sna.resetcursor",text=r"",emboss=True,depress=False,icon_value=692)
            op = box.operator("view3d.snap_cursor_to_active",text=r"Active",emboss=True,depress=False,icon_value=0)
            op = box.operator("view3d.snap_cursor_to_selected",text=r"Selected",emboss=True,depress=False,icon_value=0)
            op = box.operator("view3d.snap_cursor_to_center",text=r"World Origin",emboss=True,depress=False,icon_value=0)
            if bpy.context.scene.addgridbuttons:
                op = box.operator("view3d.snap_cursor_to_grid",text=r"Grid",emboss=True,depress=False,icon_value=0)
            else:
                pass
            box = layout.box()
            box.enabled = True
            box.alert = False
            box.scale_x = 1.0
            box.scale_y = 1.0
            box.label(text=r"Selection To",icon_value=0)
            op = box.operator("view3d.snap_selected_to_cursor",text=r"Cursor",emboss=True,depress=False,icon_value=0)
            op.use_offset = False
            op = box.operator("view3d.snap_selected_to_cursor",text=r"Cursor (Keep Offset)",emboss=True,depress=False,icon_value=0)
            op.use_offset = True
            op = box.operator("view3d.snap_selected_to_active",text=r"Active",emboss=True,depress=False,icon_value=0)
            if bpy.context.scene.addgridbuttons:
                op = box.operator("view3d.snap_selected_to_grid",text=r"Grid",emboss=True,depress=False,icon_value=0)
            else:
                pass
            op = layout.operator("sna.aligncursor",text=r"Align Cursor",emboss=True,depress=False,icon_value=0)
            op = layout.operator("sna.alignobject",text=r"Align Object",emboss=True,depress=False,icon_value=0)
        except Exception as exc:
            print(str(exc) + " | Error in Snappie pie menu")

def register_key_84992():
    kc = bpy.context.window_manager.keyconfigs.addon
    if kc:
        km = kc.keymaps.new(name="Window", space_type="EMPTY")
        kmi = km.keymap_items.new("wm.call_menu_pie",
                                    type= "S",
                                    value= "PRESS",
                                    repeat= False,
                                    ctrl=False,
                                    alt=False,
                                    shift=True)
        kmi.properties.name = "SNA_MT_Snappie_4FE70"
        addon_keymaps.append((km, kmi))


#######   Operators
class SNA_OT_Aligncursor(bpy.types.Operator):
    bl_idname = "sna.aligncursor"
    bl_label = "AlignCursor"
    bl_description = "Aligns 3D cursor to selected object"
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            function_return_3C6C9 = fnaligncursortoactive()
        except Exception as exc:
            print(str(exc) + " | Error in execute function of AlignCursor")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of AlignCursor")
        return self.execute(context)


class SNA_OT_Alignobject(bpy.types.Operator):
    bl_idname = "sna.alignobject"
    bl_label = "AlignObject"
    bl_description = "Aligns selected object to 3D cursor"
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            function_return_022A0 = fnalignobjecttocursor()
        except Exception as exc:
            print(str(exc) + " | Error in execute function of AlignObject")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of AlignObject")
        return self.execute(context)


class SNA_OT_Resetcursor(bpy.types.Operator):
    bl_idname = "sna.resetcursor"
    bl_label = "ResetCursor"
    bl_description = "Resets 3D cursor rotation to world axis"
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            function_return_F3A1B = fnresetcursor()
        except Exception as exc:
            print(str(exc) + " | Error in execute function of ResetCursor")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of ResetCursor")
        return self.execute(context)


class SNA_OT_Tweak3Dcursor(bpy.types.Operator):
    bl_idname = "sna.tweak3dcursor"
    bl_label = "Tweak3DCursor"
    bl_description = "Tweak loaction of the 3D cursor"
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Tweak3DCursor")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Tweak3DCursor")
        return context.window_manager.invoke_props_dialog(self, width=300)

    def draw(self, context):
        layout = self.layout
        try:
            layout.prop(bpy.context.scene,'cursorzaxis',text=r"CursorZAxis",emboss=True,slider=False,)
        except Exception as exc:
            print(str(exc) + " | Error in draw function of Tweak3DCursor")


class SNA_OT_Switchposition(bpy.types.Operator):
    bl_idname = "sna.switchposition"
    bl_label = "SwitchPosition"
    bl_description = "Switch positions between Home and Target"
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            function_return_262D6 = fnswitchisolationmode()
        except Exception as exc:
            print(str(exc) + " | Error in execute function of SwitchPosition")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of SwitchPosition")
        return self.execute(context)


#######   SnappiePrefsGraph
class SNA_AddonPreferences_3A8C5(bpy.types.AddonPreferences):
    bl_idname = 'snappie'

    def draw(self, context):
        try:
            layout = self.layout
            layout.prop(bpy.context.scene,'addgridbuttons',icon_value=0,text=r"Add 'Grid' snapping  buttons",emboss=True,toggle=False,invert_checkbox=False,)
            if "Window" in bpy.context.window_manager.keyconfigs.addon.keymaps:
                if "wm.call_menu_pie" in bpy.context.window_manager.keyconfigs.addon.keymaps["Window"].keymap_items:
                    kmi = bpy.context.window_manager.keyconfigs.addon.keymaps["Window"].keymap_items["wm.call_menu_pie"]
                    layout.prop(kmi, "type", text=r"Snappie Keymap", full_event=True, toggle=False)
                else:
                    layout.label(text="Couldn't find keymap item!", icon="ERROR")
            else:
                layout.label(text="Couldn't find keymap!", icon="ERROR")
        except Exception as exc:
            print(str(exc) + " | Error in addon preferences")


###############   REGISTER ICONS
def sn_register_icons():
    icons = []
    bpy.types.Scene.snappie_icons = bpy.utils.previews.new()
    icons_dir = os.path.join( os.path.dirname( __file__ ), "icons" )
    for icon in icons:
        bpy.types.Scene.snappie_icons.load( icon, os.path.join( icons_dir, icon + ".png" ), 'IMAGE' )

def sn_unregister_icons():
    bpy.utils.previews.remove( bpy.types.Scene.snappie_icons )


###############   REGISTER PROPERTIES
def sn_register_properties():
    bpy.types.Scene.cursorzaxis = bpy.props.FloatProperty(name='CursorZAxis',description='',subtype='NONE',unit='NONE',options=set(),precision=2, update=update_cursorzaxis,default=0.0)
    bpy.types.Object.targetloc = bpy.props.FloatVectorProperty(name='TargetLoc',description='',subtype='NONE',unit='NONE',options=set(),precision=2, default=(0.0, 0.0, 0.0),size=3)
    bpy.types.Object.targetrot = bpy.props.FloatVectorProperty(name='TargetRot',description='',subtype='EULER',unit='NONE',options=set(),precision=2, default=(0.0, 0.0, 0.0),size=3)
    bpy.types.Object.groupempty = bpy.props.StringProperty(name='GroupEmpty',description='',subtype='NONE',options=set(),default='')
    bpy.types.Object.homeloc = bpy.props.FloatVectorProperty(name='HomeLoc',description='',subtype='NONE',unit='NONE',options=set(),precision=2, default=(0.0, 0.0, 0.0),size=3)
    bpy.types.Object.homerot = bpy.props.FloatVectorProperty(name='HomeRot',description='',subtype='EULER',unit='NONE',options=set(),precision=2, default=(0.0, 0.0, 0.0),size=3)
    bpy.types.Object.hometoggle = bpy.props.BoolProperty(name='HomeToggle',description='ON sets Home to current location. OFF sets to world origin.',options=set(),update=update_hometoggle,default=False)
    bpy.types.Object.targettoggle = bpy.props.BoolProperty(name='TargetToggle',description='ON sets Target to current location. OFF sets to world origin.',options=set(),update=update_targettoggle,default=False)
    bpy.types.Object.switchtoggle = bpy.props.BoolProperty(name='SwitchToggle',description='',options=set(),default=False)
    bpy.types.Scene.addgridbuttons = bpy.props.BoolProperty(name='AddGridButtons',description='',options=set(),default=False)

def sn_unregister_properties():
    del bpy.types.Scene.cursorzaxis
    del bpy.types.Object.targetloc
    del bpy.types.Object.targetrot
    del bpy.types.Object.groupempty
    del bpy.types.Object.homeloc
    del bpy.types.Object.homerot
    del bpy.types.Object.hometoggle
    del bpy.types.Object.targettoggle
    del bpy.types.Object.switchtoggle
    del bpy.types.Scene.addgridbuttons


###############   REGISTER ADDON
def register():
    sn_register_icons()
    sn_register_properties()
    bpy.utils.register_class(SNA_MT_Snappie_4FE70)
    register_key_84992()
    bpy.utils.register_class(SNA_OT_Aligncursor)
    bpy.utils.register_class(SNA_OT_Alignobject)
    bpy.utils.register_class(SNA_OT_Resetcursor)
    bpy.utils.register_class(SNA_OT_Tweak3Dcursor)
    bpy.utils.register_class(SNA_OT_Switchposition)
    bpy.utils.register_class(SNA_AddonPreferences_3A8C5)


###############   UNREGISTER ADDON
def unregister():
    sn_unregister_icons()
    sn_unregister_properties()
    bpy.utils.unregister_class(SNA_AddonPreferences_3A8C5)
    bpy.utils.unregister_class(SNA_OT_Switchposition)
    bpy.utils.unregister_class(SNA_OT_Tweak3Dcursor)
    bpy.utils.unregister_class(SNA_OT_Resetcursor)
    bpy.utils.unregister_class(SNA_OT_Alignobject)
    bpy.utils.unregister_class(SNA_OT_Aligncursor)
    for km,kmi in addon_keymaps:
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    bpy.utils.unregister_class(SNA_MT_Snappie_4FE70)