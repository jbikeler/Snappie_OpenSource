# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "Snappie",
    "author" : "ro0nik", 
    "description" : "",
    "blender" : (4, 4, 0),
    "version" : (3, 1, 0),
    "location" : "",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "3D View" 
}


import bpy
import bpy.utils.previews
from mathutils import Matrix


addon_keymaps = {}
_icons = None


def find_user_keyconfig(key):
    km, kmi = addon_keymaps[key]
    for item in bpy.context.window_manager.keyconfigs.user.keymaps[km.name].keymap_items:
        found_item = False
        if kmi.idname == item.idname:
            found_item = True
            for name in dir(kmi.properties):
                if not name in ["bl_rna", "rna_type"] and not name[0] == "_":
                    if name in kmi.properties and name in item.properties and not kmi.properties[name] == item.properties[name]:
                        found_item = False
        if found_item:
            return item
    print(f"Couldn't find keymap item for {key}, using addon keymap instead. This won't be saved across sessions!")
    return kmi


def sna_formatchangelog_2DFCA_2938D():
    return 'Changelog Version ' + str(tuple(tuple(bpy.context.scene.sn.version))).replace('(', '').replace(')', '').replace(',', '.').replace(' ', '') + ':'


class SNA_OT_Align_Cursor_To_Object_6010F(bpy.types.Operator):
    bl_idname = "sna.align_cursor_to_object_6010f"
    bl_label = "Align Cursor to Object"
    bl_description = "Align the 3D cursor's location and rotation to the active object."
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        should_align_to_normal = bpy.context.scene.sna_aligntonormal
        # ---------------------------------------------------------------------------
        # Helper functions
        # ---------------------------------------------------------------------------

        def align_cursor_to_normal(context):
            """Rotate the 3-D cursor to match the active element’s normal,
            keeping its position unchanged."""
            scene  = context.scene
            cursor = scene.cursor
            prev_orient = scene.transform_orientation_slots[0].type
            scene.transform_orientation_slots[0].type = 'NORMAL'
            bpy.ops.transform.create_orientation(name='___TMP___', use=True, overwrite=True)
            mat = scene.transform_orientation_slots[0].custom_orientation.matrix.to_4x4()
            cursor.matrix = Matrix.Translation(cursor.location) @ mat
            bpy.ops.transform.delete_orientation()
            scene.transform_orientation_slots[0].type = prev_orient

        def snap_cursor_position(context, align_to_normal: bool = False):
            """Snap the 3-D cursor to selection/active element.
               If *align_to_normal* is True, also rotate the cursor.
               Silently returns if nothing is selected."""
            if context.mode == 'EDIT_MESH':
                obj = context.active_object
                if not obj or obj.type != 'MESH':
                    return
                mesh = obj.data
                if (
                    mesh.total_vert_sel == 0 and
                    mesh.total_edge_sel == 0 and
                    mesh.total_face_sel == 0
                ):
                    return  # nothing selected → exit
                bpy.ops.view3d.snap_cursor_to_selected()
            else:  # Object Mode
                if context.active_object is None:
                    return
                bpy.ops.view3d.snap_cursor_to_active()
            if align_to_normal:
                align_cursor_to_normal(context)
        snap_cursor_position(context, align_to_normal = should_align_to_normal)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Align_Object_To_Cursor_047Aa(bpy.types.Operator):
    bl_idname = "sna.align_object_to_cursor_047aa"
    bl_label = "Align Object to Cursor"
    bl_description = "Align the active object's location and rotation to the 3D cursor."
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_alignobject_0E568()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_alignobject_0E568():
    if bpy.context.view_layer.objects.active:
        bpy.context.view_layer.objects.active.location = bpy.context.scene.cursor.location
        bpy.context.scene.cursor.rotation_mode = 'XYZ'
        bpy.context.view_layer.objects.active.rotation_mode = 'XYZ'
        bpy.context.view_layer.objects.active.rotation_euler = bpy.context.scene.cursor.rotation_euler


def sna_add_to_view3d_mt_editor_menus_20C4B(self, context):
    if not (False):
        layout = self.layout
        row_3D96F = layout.row(heading='', align=False)
        row_3D96F.alert = False
        row_3D96F.enabled = True
        row_3D96F.active = True
        row_3D96F.use_property_split = False
        row_3D96F.use_property_decorate = False
        row_3D96F.scale_x = 1.0
        row_3D96F.scale_y = 1.0
        row_3D96F.alignment = 'Expand'.upper()
        row_3D96F.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_3D96F.separator(factor=0.0)
        row_3D96F.prop(bpy.context.scene, 'sna_aligntonormal', text='', icon_value=454, emboss=True)
        row_3D96F.separator(factor=0.8500000238418579)


def sna_resetobjectloc_00942():
    for i_4607A in range(len(bpy.context.view_layer.objects.selected)):
        bpy.context.view_layer.objects.selected[i_4607A].location = (0.0, 0.0, 0.0)


def sna_resetobjectrot_D604C():
    for i_BEBBF in range(len(bpy.context.view_layer.objects.selected)):
        bpy.context.view_layer.objects.selected[i_BEBBF].rotation_mode = 'XYZ'
        bpy.context.view_layer.objects.selected[i_BEBBF].rotation_euler = (0.0, 0.0, 0.0)


def sna_resetobjectscale_1AE38():
    for i_0BB78 in range(len(bpy.context.view_layer.objects.selected)):
        pass
    bpy.context.view_layer.objects.selected[i_0BB78].scale = (1.0, 1.0, 1.0)


def sna_reset3dcloc_578AA():
    if bpy.context.view_layer.objects.active:
        bpy.context.scene.cursor.location = (0.0, 0.0, 0.0)


def sna_reset3dcrot_01BFE():
    if bpy.context.view_layer.objects.active:
        bpy.context.scene.cursor.rotation_mode = 'XYZ'
        bpy.context.scene.cursor.rotation_euler = (0.0, 0.0, 0.0)


class SNA_OT_Reset_Objects_Location_E6410(bpy.types.Operator):
    bl_idname = "sna.reset_objects_location_e6410"
    bl_label = "Reset Objects Location"
    bl_description = "Will reset all objects locations to the world origin at (0,0,0)."
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_resetobjectloc_00942()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Reset_Objects_Rotation_62A81(bpy.types.Operator):
    bl_idname = "sna.reset_objects_rotation_62a81"
    bl_label = "Reset Objects Rotation"
    bl_description = "Reset the rotation of all selected objects to (0,0,0). Currently will force object into Euler Mode"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_resetobjectrot_D604C()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Reset_Objects_Scale_1A86C(bpy.types.Operator):
    bl_idname = "sna.reset_objects_scale_1a86c"
    bl_label = "Reset Objects Scale"
    bl_description = "Set all selected objects scale to (1,1,1)."
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_resetobjectscale_1AE38()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Reset_3D_Cursors_Location_Eb113(bpy.types.Operator):
    bl_idname = "sna.reset_3d_cursors_location_eb113"
    bl_label = "Reset 3D Cursors Location"
    bl_description = "Sets the 3D Cursor's location to (0,0,0) "
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_reset3dcloc_578AA()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Reset_3D_Cursor_Rotation_23E02(bpy.types.Operator):
    bl_idname = "sna.reset_3d_cursor_rotation_23e02"
    bl_label = "Reset 3D Cursor Rotation"
    bl_description = "Sets the 3D cursors rotation to  0,0,0. Currently will force object into Euler Mode."
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_reset3dcrot_01BFE()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_D_Cursor_Reset_Ac368(bpy.types.Operator):
    bl_idname = "sna.d_cursor_reset_ac368"
    bl_label = "3D Cursor Reset"
    bl_description = "Reset location and rotation of the 3D Cursor with one click"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_resetcursor_2125C()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_resetcursor_2125C():
    sna_reset3dcloc_578AA()
    sna_reset3dcrot_01BFE()


class SNA_OT_Set_Object_Home_53Db0(bpy.types.Operator):
    bl_idname = "sna.set_object_home_53db0"
    bl_label = "Set Object Home"
    bl_description = "Toggling this option will set the Home location for the active object. (Highlighted means it's set). When toggling off the Home location it will remember the last saved Home location until it is toggled on again."
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_sethome_E8B1D()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_sethome_E8B1D():
    if bpy.context.view_layer.objects.active:
        if bpy.context.view_layer.objects.active.sna_homeisset:
            bpy.context.view_layer.objects.active.sna_homeisset = False
        else:
            bpy.context.view_layer.objects.active.sna_homeisset = True
            bpy.context.view_layer.objects.active.sna_homeloc = bpy.context.view_layer.objects.active.location
            bpy.context.view_layer.objects.active.sna_homerot = bpy.context.view_layer.objects.active.rotation_euler
            bpy.context.view_layer.objects.active.sna_homescale = bpy.context.view_layer.objects.active.scale


def sna_switchisolation_83659():
    if bpy.context.view_layer.objects.active.sna_isathome:
        bpy.context.view_layer.objects.active.location = bpy.context.view_layer.objects.active.sna_targetloc
        bpy.context.view_layer.objects.active.rotation_euler = bpy.context.view_layer.objects.active.sna_targetrot
        bpy.context.view_layer.objects.active.scale = bpy.context.view_layer.objects.active.sna_targetscale
        bpy.context.view_layer.objects.active.sna_isathome = False
    else:
        bpy.context.view_layer.objects.active.location = bpy.context.view_layer.objects.active.sna_homeloc
        bpy.context.view_layer.objects.active.rotation_euler = bpy.context.view_layer.objects.active.sna_homerot
        bpy.context.view_layer.objects.active.scale = bpy.context.view_layer.objects.active.sna_homescale
        bpy.context.view_layer.objects.active.sna_isathome = True


class SNA_OT_Switch_Isolation_Mode_Bbba6(bpy.types.Operator):
    bl_idname = "sna.switch_isolation_mode_bbba6"
    bl_label = "Switch Isolation Mode"
    bl_description = "The switch will toggle back and forth between the object's Home and Target location."
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_switchisolation_83659()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_Object_Target_9De54(bpy.types.Operator):
    bl_idname = "sna.set_object_target_9de54"
    bl_label = "Set Object Target"
    bl_description = "Toggling this option will set the Target location for the active object. (Highlighted means it's set). When toggling off the Target location it will remember the last saved Target location until it is toggled on again."
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_settarget_52172()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_settarget_52172():
    if bpy.context.view_layer.objects.active:
        if bpy.context.view_layer.objects.active.sna_targetisset:
            bpy.context.view_layer.objects.active.sna_targetisset = False
        else:
            bpy.context.view_layer.objects.active.sna_targetisset = True
            bpy.context.view_layer.objects.active.sna_targetloc = bpy.context.view_layer.objects.active.location
            bpy.context.view_layer.objects.active.sna_targetrot = bpy.context.view_layer.objects.active.rotation_euler
            bpy.context.view_layer.objects.active.sna_targetscale = bpy.context.view_layer.objects.active.scale


class SNA_MT_4A940(bpy.types.Menu):
    bl_idname = "SNA_MT_4A940"
    bl_label = "Snappie"

    @classmethod
    def poll(cls, context):
        return not ((not (('OBJECT'==bpy.context.mode or 'EDIT_MESH'==bpy.context.mode) and bpy.context.view_layer.objects.active)))

    def draw(self, context):
        layout = self.layout.menu_pie()
        layout.separator(factor=1.0)
        layout.separator(factor=1.0)
        layout.separator(factor=1.0)
        box_8B859 = layout.box()
        box_8B859.alert = False
        box_8B859.enabled = True
        box_8B859.active = True
        box_8B859.use_property_split = False
        box_8B859.use_property_decorate = False
        box_8B859.alignment = 'Expand'.upper()
        box_8B859.scale_x = 1.9000000953674316
        box_8B859.scale_y = 1.0
        if not True: box_8B859.operator_context = "EXEC_DEFAULT"
        col_7E941 = box_8B859.column(heading='', align=False)
        col_7E941.alert = False
        col_7E941.enabled = True
        col_7E941.active = True
        col_7E941.use_property_split = False
        col_7E941.use_property_decorate = False
        col_7E941.scale_x = 1.0
        col_7E941.scale_y = 1.2999999523162842
        col_7E941.alignment = 'Expand'.upper()
        col_7E941.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_0C767 = col_7E941.row(heading='', align=True)
        row_0C767.alert = False
        row_0C767.enabled = True
        row_0C767.active = True
        row_0C767.use_property_split = False
        row_0C767.use_property_decorate = False
        row_0C767.scale_x = 1.0
        row_0C767.scale_y = 1.0
        row_0C767.alignment = 'Expand'.upper()
        row_0C767.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_0C767.operator('sna.set_object_home_53db0', text='', icon_value=655, emboss=True, depress=bpy.context.view_layer.objects.active.sna_homeisset)
        op = row_0C767.operator('sna.set_object_target_9de54', text='', icon_value=553, emboss=True, depress=bpy.context.view_layer.objects.active.sna_targetisset)
        op = col_7E941.operator('sna.switch_isolation_mode_bbba6', text='', icon_value=46, emboss=True, depress=False)
        box_8E657 = layout.box()
        box_8E657.alert = False
        box_8E657.enabled = True
        box_8E657.active = True
        box_8E657.use_property_split = False
        box_8E657.use_property_decorate = False
        box_8E657.alignment = 'Center'.upper()
        box_8E657.scale_x = 1.9000000953674316
        box_8E657.scale_y = 1.0
        if not True: box_8E657.operator_context = "EXEC_DEFAULT"
        col_6392B = box_8E657.column(heading='', align=False)
        col_6392B.alert = False
        col_6392B.enabled = True
        col_6392B.active = True
        col_6392B.use_property_split = False
        col_6392B.use_property_decorate = False
        col_6392B.scale_x = 1.0
        col_6392B.scale_y = 1.2999999523162842
        col_6392B.alignment = 'Expand'.upper()
        col_6392B.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_67B8F = col_6392B.row(heading='', align=True)
        row_67B8F.alert = False
        row_67B8F.enabled = True
        row_67B8F.active = True
        row_67B8F.use_property_split = False
        row_67B8F.use_property_decorate = False
        row_67B8F.scale_x = 1.0
        row_67B8F.scale_y = 1.0
        row_67B8F.alignment = 'Expand'.upper()
        row_67B8F.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_67B8F.label(text='Cursor To', icon_value=0)
        row_204BA = row_67B8F.row(heading='', align=True)
        row_204BA.alert = False
        row_204BA.enabled = True
        row_204BA.active = True
        row_204BA.use_property_split = False
        row_204BA.use_property_decorate = False
        row_204BA.scale_x = 1.0
        row_204BA.scale_y = 1.0
        row_204BA.alignment = 'Right'.upper()
        row_204BA.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_204BA.operator('sna.d_cursor_reset_ac368', text='', icon_value=121, emboss=True, depress=False)
        op = row_204BA.operator('sna.reset_3d_cursor_rotation_23e02', text='', icon_value=647, emboss=True, depress=False)
        col_6392B.separator(factor=0.5)
        op = col_6392B.operator('view3d.snap_cursor_to_active', text='Active', icon_value=0, emboss=True, depress=False)
        op = col_6392B.operator('view3d.snap_cursor_to_selected', text='Selected', icon_value=0, emboss=True, depress=False)
        op = col_6392B.operator('view3d.snap_cursor_to_center', text='World Origin', icon_value=0, emboss=True, depress=False)
        if bpy.context.scene.sna_showgrid:
            op = col_6392B.operator('view3d.snap_selected_to_grid', text='Grid', icon_value=0, emboss=True, depress=False)
        box_CFEEB = layout.box()
        box_CFEEB.alert = False
        box_CFEEB.enabled = True
        box_CFEEB.active = True
        box_CFEEB.use_property_split = False
        box_CFEEB.use_property_decorate = False
        box_CFEEB.alignment = 'Center'.upper()
        box_CFEEB.scale_x = 1.1770001649856567
        box_CFEEB.scale_y = 1.0
        if not True: box_CFEEB.operator_context = "EXEC_DEFAULT"
        col_CA207 = box_CFEEB.column(heading='', align=False)
        col_CA207.alert = False
        col_CA207.enabled = True
        col_CA207.active = True
        col_CA207.use_property_split = False
        col_CA207.use_property_decorate = False
        col_CA207.scale_x = 1.0
        col_CA207.scale_y = 1.2999999523162842
        col_CA207.alignment = 'Expand'.upper()
        col_CA207.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_CC770 = col_CA207.row(heading='', align=True)
        row_CC770.alert = False
        row_CC770.enabled = True
        row_CC770.active = True
        row_CC770.use_property_split = False
        row_CC770.use_property_decorate = False
        row_CC770.scale_x = 1.0
        row_CC770.scale_y = 1.0
        row_CC770.alignment = 'Expand'.upper()
        row_CC770.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_CC770.label(text='Selected To', icon_value=0)
        row_E0DB3 = row_CC770.row(heading='', align=True)
        row_E0DB3.alert = False
        row_E0DB3.enabled = True
        row_E0DB3.active = True
        row_E0DB3.use_property_split = False
        row_E0DB3.use_property_decorate = False
        row_E0DB3.scale_x = 1.3300000429153442
        row_E0DB3.scale_y = 1.0
        row_E0DB3.alignment = 'Right'.upper()
        row_E0DB3.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_E0DB3.operator('sna.reset_objects_rotation_62a81', text='', icon_value=647, emboss=True, depress=False)
        col_CA207.separator(factor=0.5)
        op = col_CA207.operator('view3d.snap_selected_to_active', text='Active', icon_value=0, emboss=True, depress=False)
        row_F3DDC = col_CA207.row(heading='', align=True)
        row_F3DDC.alert = False
        row_F3DDC.enabled = True
        row_F3DDC.active = True
        row_F3DDC.use_property_split = False
        row_F3DDC.use_property_decorate = False
        row_F3DDC.scale_x = 1.0
        row_F3DDC.scale_y = 1.0
        row_F3DDC.alignment = 'Expand'.upper()
        row_F3DDC.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_F3DDC.operator('view3d.snap_selected_to_cursor', text='Cursor', icon_value=0, emboss=True, depress=False)
        op.use_offset = False
        op = row_F3DDC.operator('sna.snap_selection_to_cursor_keep_offset_a9b06', text='3DC Offset', icon_value=0, emboss=True, depress=False)
        op = col_CA207.operator('sna.reset_objects_location_e6410', text='World Origin', icon_value=0, emboss=True, depress=False)
        if bpy.context.scene.sna_showgrid:
            op = col_CA207.operator('view3d.snap_selected_to_grid', text='Grid', icon_value=0, emboss=True, depress=False)
        op = layout.operator('sna.align_cursor_to_object_6010f', text='Align Cursor', icon_value=0, emboss=True, depress=False)
        op = layout.operator('sna.align_object_to_cursor_047aa', text='Align Object', icon_value=0, emboss=True, depress=False)


class SNA_OT_Snap_Selection_To_Cursor_Keep_Offset_A9B06(bpy.types.Operator):
    bl_idname = "sna.snap_selection_to_cursor_keep_offset_a9b06"
    bl_label = "Snap Selection To Cursor Keep Offset"
    bl_description = "Snaps all selected objects to the 3D Cursor but maintains the offset of each object in relation to each other using the 3D Cursor as the center of the transform."
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        prev_context = bpy.context.area.type
        bpy.context.area.type = 'VIEW_3D'
        bpy.ops.view3d.snap_selected_to_cursor('INVOKE_DEFAULT', use_offset=True)
        bpy.context.area.type = prev_context
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_AddonPreferences_C3BE8(bpy.types.AddonPreferences):
    bl_idname = __package__

    def draw(self, context):
        if not (False):
            layout = self.layout 
            box_796C1 = layout.box()
            box_796C1.alert = False
            box_796C1.enabled = True
            box_796C1.active = True
            box_796C1.use_property_split = False
            box_796C1.use_property_decorate = False
            box_796C1.alignment = 'Expand'.upper()
            box_796C1.scale_x = 1.0
            box_796C1.scale_y = 1.0
            if not True: box_796C1.operator_context = "EXEC_DEFAULT"
            box_796C1.label(text='Keyboard Shortcuts', icon_value=0)
            row_1ADB2 = box_796C1.row(heading='', align=False)
            row_1ADB2.alert = False
            row_1ADB2.enabled = True
            row_1ADB2.active = True
            row_1ADB2.use_property_split = False
            row_1ADB2.use_property_decorate = False
            row_1ADB2.scale_x = 1.0
            row_1ADB2.scale_y = 1.0
            row_1ADB2.alignment = 'Expand'.upper()
            row_1ADB2.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_1ADB2.prop(find_user_keyconfig('19A8E'), 'type', text='', full_event=True)
            row_F9AE1 = row_1ADB2.row(heading='', align=False)
            row_F9AE1.alert = False
            row_F9AE1.enabled = True
            row_F9AE1.active = True
            row_F9AE1.use_property_split = False
            row_F9AE1.use_property_decorate = False
            row_F9AE1.scale_x = 1.0
            row_F9AE1.scale_y = 1.0
            row_F9AE1.alignment = 'Right'.upper()
            row_F9AE1.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            layout.prop(bpy.context.scene, 'sna_showgrid', text="Show 'Snap To Grid' Options", icon_value=0, emboss=True)
            layout.label(text='Warning: This version was updated for Blender v4.3 and might not work with earlier versions. If you need Snappie for Blender v4-4.2 look at the initial release on the GitHub', icon_value=707)
            box_FFAE1 = layout.box()
            box_FFAE1.alert = False
            box_FFAE1.enabled = True
            box_FFAE1.active = True
            box_FFAE1.use_property_split = False
            box_FFAE1.use_property_decorate = False
            box_FFAE1.alignment = 'Expand'.upper()
            box_FFAE1.scale_x = 1.0
            box_FFAE1.scale_y = 1.0
            if not True: box_FFAE1.operator_context = "EXEC_DEFAULT"
            box_FFAE1.label(text=sna_formatchangelog_2DFCA_2938D(), icon_value=0)
            box_FFAE1.label(text='Added: Align Cursor now can align to the normals of faces, edges, and verts.', icon_value=58)
            box_FFAE1.label(text='Added: Option for aligning to the normal is a toggle button in the header menu next to the Mode Selection Box with the same icon as this bullet point', icon_value=454)
            box_FFAE1.label(text='PLANNED:', icon_value=0)
            box_FFAE1.label(text='Rewrite for the function in Serpens', icon_value=58)
            box_FFAE1.label(text='3D Cursor Gizmo', icon_value=58)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.types.Object.sna_homeisset = bpy.props.BoolProperty(name='HomeIsSet', description='', default=False)
    bpy.types.Object.sna_targetisset = bpy.props.BoolProperty(name='TargetIsSet', description='', default=False)
    bpy.types.Object.sna_homeloc = bpy.props.FloatVectorProperty(name='HomeLoc', description='', size=3, default=(0.0, 0.0, 0.0), subtype='NONE', unit='NONE', step=3, precision=6)
    bpy.types.Object.sna_homerot = bpy.props.FloatVectorProperty(name='HomeRot', description='', size=3, default=(0.0, 0.0, 0.0), subtype='NONE', unit='NONE', step=3, precision=6)
    bpy.types.Object.sna_homescale = bpy.props.FloatVectorProperty(name='HomeScale', description='', size=3, default=(0.0, 0.0, 0.0), subtype='NONE', unit='NONE', step=3, precision=6)
    bpy.types.Object.sna_targetloc = bpy.props.FloatVectorProperty(name='TargetLoc', description='', size=3, default=(0.0, 0.0, 0.0), subtype='NONE', unit='NONE', step=3, precision=6)
    bpy.types.Object.sna_targetrot = bpy.props.FloatVectorProperty(name='TargetRot', description='', size=3, default=(0.0, 0.0, 0.0), subtype='NONE', unit='NONE', step=3, precision=6)
    bpy.types.Object.sna_targetscale = bpy.props.FloatVectorProperty(name='TargetScale', description='', size=3, default=(0.0, 0.0, 0.0), subtype='NONE', unit='NONE', step=3, precision=6)
    bpy.types.Object.sna_isathome = bpy.props.BoolProperty(name='IsAtHome', description='', default=False)
    bpy.types.Scene.sna_showgrid = bpy.props.BoolProperty(name='ShowGrid', description='', default=False)
    bpy.types.Scene.sna_aligntonormal = bpy.props.BoolProperty(name='AlignToNormal', description='', default=True)
    bpy.utils.register_class(SNA_OT_Align_Cursor_To_Object_6010F)
    bpy.utils.register_class(SNA_OT_Align_Object_To_Cursor_047Aa)
    bpy.types.VIEW3D_MT_editor_menus.prepend(sna_add_to_view3d_mt_editor_menus_20C4B)
    bpy.utils.register_class(SNA_OT_Reset_Objects_Location_E6410)
    bpy.utils.register_class(SNA_OT_Reset_Objects_Rotation_62A81)
    bpy.utils.register_class(SNA_OT_Reset_Objects_Scale_1A86C)
    bpy.utils.register_class(SNA_OT_Reset_3D_Cursors_Location_Eb113)
    bpy.utils.register_class(SNA_OT_Reset_3D_Cursor_Rotation_23E02)
    bpy.utils.register_class(SNA_OT_D_Cursor_Reset_Ac368)
    bpy.utils.register_class(SNA_OT_Set_Object_Home_53Db0)
    bpy.utils.register_class(SNA_OT_Switch_Isolation_Mode_Bbba6)
    bpy.utils.register_class(SNA_OT_Set_Object_Target_9De54)
    bpy.utils.register_class(SNA_MT_4A940)
    bpy.utils.register_class(SNA_OT_Snap_Selection_To_Cursor_Keep_Offset_A9B06)
    bpy.utils.register_class(SNA_AddonPreferences_C3BE8)
    kc = bpy.context.window_manager.keyconfigs.addon
    km = kc.keymaps.new(name='3D View', space_type='VIEW_3D')
    kmi = km.keymap_items.new('wm.call_menu_pie', 'S', 'PRESS',
        ctrl=False, alt=False, shift=True, repeat=False)
    kmi.properties.name = 'SNA_MT_4A940'
    addon_keymaps['19A8E'] = (km, kmi)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.sna_aligntonormal
    del bpy.types.Scene.sna_showgrid
    del bpy.types.Object.sna_isathome
    del bpy.types.Object.sna_targetscale
    del bpy.types.Object.sna_targetrot
    del bpy.types.Object.sna_targetloc
    del bpy.types.Object.sna_homescale
    del bpy.types.Object.sna_homerot
    del bpy.types.Object.sna_homeloc
    del bpy.types.Object.sna_targetisset
    del bpy.types.Object.sna_homeisset
    bpy.utils.unregister_class(SNA_OT_Align_Cursor_To_Object_6010F)
    bpy.utils.unregister_class(SNA_OT_Align_Object_To_Cursor_047Aa)
    bpy.types.VIEW3D_MT_editor_menus.remove(sna_add_to_view3d_mt_editor_menus_20C4B)
    bpy.utils.unregister_class(SNA_OT_Reset_Objects_Location_E6410)
    bpy.utils.unregister_class(SNA_OT_Reset_Objects_Rotation_62A81)
    bpy.utils.unregister_class(SNA_OT_Reset_Objects_Scale_1A86C)
    bpy.utils.unregister_class(SNA_OT_Reset_3D_Cursors_Location_Eb113)
    bpy.utils.unregister_class(SNA_OT_Reset_3D_Cursor_Rotation_23E02)
    bpy.utils.unregister_class(SNA_OT_D_Cursor_Reset_Ac368)
    bpy.utils.unregister_class(SNA_OT_Set_Object_Home_53Db0)
    bpy.utils.unregister_class(SNA_OT_Switch_Isolation_Mode_Bbba6)
    bpy.utils.unregister_class(SNA_OT_Set_Object_Target_9De54)
    bpy.utils.unregister_class(SNA_MT_4A940)
    bpy.utils.unregister_class(SNA_OT_Snap_Selection_To_Cursor_Keep_Offset_A9B06)
    bpy.utils.unregister_class(SNA_AddonPreferences_C3BE8)
